export const environment = {
  firebase: {
    apiKey: "AIzaSyBTvVUVnq9XqkKMLRoUIkhDzHlJsZrHB_E",
    authDomain: "spacex-c31c1.firebaseapp.com",
    projectId: "spacex-c31c1",
    storageBucket: "spacex-c31c1.firebasestorage.app",
    messagingSenderId: "238180389858",
    appId: "1:238180389858:web:000a2555eb1a6a22d49fbb",
    measurementId: "G-EMBELDC1TX"
  }
};
